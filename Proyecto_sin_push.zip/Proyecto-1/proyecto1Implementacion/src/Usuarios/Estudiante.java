package Usuarios;

import System.Actividad;
import System.LearningPath;
import System.Sistema;

import java.util.ArrayList;
import java.util.HashMap;

public class Estudiante extends Usuario {
    private HashMap<String, String> intereses; // Mapa de intereses
    private ArrayList<LearningPath> learningPathsInscritos; // Lista de Learning Paths

    // Constructor modificado para aceptar una lista de Learning Paths
    public Estudiante(String login, String password, String correo, ArrayList<LearningPath> learningPathsInscritos) {
        super(login, password, correo);
        this.intereses = new HashMap<>();
        this.learningPathsInscritos = (learningPathsInscritos != null) ? learningPathsInscritos : new ArrayList<>();
    }

    public void calificarActividad(Actividad actividad, int calificacion) {
        if (calificacion >= 0 && calificacion <= 5) {
            actividad.calificarEstudiante(this, calificacion);
            System.out.println("Actividad calificada con éxito.");
        } else {
            System.out.println("La calificación debe estar entre 0 y 5.");
        }
    }
    // Método getID que devuelve el login como identificador (ID)
    public int getID() {
        return Math.abs(this.getLogin().hashCode()); // Convertimos el login a un valor numérico único
    }

    public void publicarReseña(String reseña, Actividad actividad) {
        if (actividad != null) {
            actividad.agregarReseña(reseña);
            System.out.println("Reseña publicada con éxito.");
        } else {
            System.out.println("No se puede publicar la reseña. Actividad no válida.");
        }
    }

    public void inscribirLearningPath(LearningPath learningPath) {
        if (learningPath != null) {
            if (!learningPathsInscritos.contains(learningPath)) {
                learningPathsInscritos.add(learningPath);
                System.out.println("Inscrito en el Learning Path: " + learningPath.getTitulo());
            } else {
                System.out.println("Ya está inscrito en este Learning Path.");
            }
        } else {
            System.out.println("El Learning Path no es válido.");
        }
    }

    public void iniciarActividad(Actividad actividad) {
        // Lógica la actividad a Completado
        System.out.println("Iniciando actividad: " + actividad.getNombre());
    }

    public HashMap<String, String> getIntereses() {
        return intereses;
    }

    public ArrayList<LearningPath> getLearningPathsInscritos() {
        return learningPathsInscritos;
    }

    public void agregarInteres(String area, String descripcion) {
        intereses.put(area, descripcion);
        System.out.println("Interés agregado: " + area);
    }
}
