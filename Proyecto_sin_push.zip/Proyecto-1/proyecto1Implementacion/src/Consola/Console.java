package Consola;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;	

import System.Actividad;
import System.Examen;
import System.LearningPath;
import System.Opcion;
import System.Pregunta;
import System.PreguntaOpcionMultiple;
import System.Quiz;
import System.Sistema;
import Usuarios.Profesor;	
import Usuarios.Estudiante;

public class Console {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean run = true;
		Sistema sistema = new Sistema();
		sistema.cargarSistema();
		Scanner scanner = new Scanner(System.in);
		while (run) {
			run = menu(sistema, scanner);
			
		}
		scanner.close();
	}
	
	
	public static boolean menu(Sistema sistema, Scanner scanner) {
		try {
			
			int option = menuInicio(scanner);
			if (option==3) {
				return false;
			}else if (option == 2){
				menuCreacionUsuario(sistema, scanner);
				
				return true;
			}else {
				menuInicioSesion(sistema, scanner);
				return true;
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("\n"+e.getMessage()+"\n");
			return true;
		}
	}
	
	
	
	public static int menuInicio(Scanner scanner) throws IOException {
		
		System.out.println("_____________________________________");
		System.out.println("BIENVENIDO:");
		System.out.println("1.) Iniciar sesión");
		System.out.println("2.) ¿Eres nuevo? ¡Registrate!");
		System.out.println("3.) Salir");
		System.out.println("_____________________________________");
		System.out.println("Digite la opcion que desea escoger:");
		int respuesta = scanner.nextInt();
		if (respuesta != 1 && respuesta != 2 && respuesta != 3) {
		    throw new IOException("Digito mal la opción");
		}
		
		return respuesta;
		
	}
	
	
	
	public static void menuCreacionUsuario(Sistema sistema, Scanner scanner) {
		System.out.println("\nPor favor digite los siguientes datos necesarios para la formalización de su perfil de usuario\n");
		
		System.out.println("\n Nombre de usuario: \n");
		String login = scanner.next();
		System.out.println("\n Contraseña: \n");
		String password = scanner.next();
		System.out.println("\n Correo: \n");
		String correo = scanner.next();
		System.out.println("\n ¿Usted es un estudiante o un profesor?");
		String tipo = scanner.next();
		
		try {
			sistema.crearUsuario(login, password, correo, tipo, true );
			System.out.println("SU USUARIO FUE CREADO EXITOSAMENTE");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
	}
	
	
	
	
	public static void menuInicioSesion(Sistema sistema, Scanner scanner) {
	    boolean sesionActiva = false; // Variable para controlar el flujo de inicio de sesión
	    while (!sesionActiva) {
	        System.out.println("\nPor favor digite los siguientes datos para iniciar su sesión:\n");
	        System.out.print("Nombre de usuario: ");
	        String login = scanner.next();
	        System.out.print("Contraseña: ");
	        String password = scanner.next();

	        try {
	            String message = sistema.iniciarSesion(login, password);
	            System.out.println(message);

	            // Comprueba si el inicio de sesión fue exitoso
	            if (message.equals("¡Inicio sesión correctamente '" + login + "'!")) {
	                sesionActiva = true; // Cambiar el estado de la sesión si el inicio es exitoso
	                menuAplicacion(sistema, scanner); // Llamar al menú de aplicación si el inicio de sesión es exitoso
	            } else {
	                System.out.println("Usuario o contraseña incorrectos. Inténtalo de nuevo."); // Mensaje de error
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	            System.out.println("Ha ocurrido un error al intentar iniciar sesión. Por favor, inténtalo más tarde.");
	        }
	    }
	}


	public static void menuAplicacion(Sistema sistema, Scanner scanner) throws SQLException {
	    // Asegúrate de que la sesión se haya establecido correctamente
	    if (sistema.getSession() == null) {
	        System.out.println("No hay una sesión activa. Debes iniciar sesión primero.");
	        return; // Salir si no hay sesión activa
	    }
	    
	    if (sistema.getSession().getClass().getSimpleName().equals("Estudiante")) {
	        boolean runSession = true;
	        while (runSession) {
	            runSession = menuAplicacionEstudiante(sistema, scanner);
	        }
	    } else {
	        menuAplicacionProfesor(sistema, scanner);
	    }
	}

	
	
	
	public static boolean menuAplicacionEstudiante(Sistema sistema, Scanner scanner) throws SQLException {
	    Estudiante estudiante = (Estudiante) sistema.getSession(); // Asegúrate de obtener el objeto Estudiante de la sesión

	    while (true) {
	        System.out.println("\n--- Menú del Estudiante ---");
	        System.out.println("[1] Consultar mis Learning Paths inscritos");
	        System.out.println("[2] Iniciar actividad");
	        System.out.println("[3] Calificar actividad");
	        System.out.println("[4] Publicar reseña");
	        System.out.println("[5] Inscribirse en un Learning Path");
	        System.out.println("[6] Cerrar sesión");
	        System.out.print("¿Qué desea hacer? ");

	        int opcion = scanner.nextInt();
	        scanner.nextLine(); // Consumir la línea

	        switch (opcion) {
	            case 1:
	                // Consultar Learning Paths inscritos
	                System.out.println("--- Learning Paths Inscritos ---");
	                for (LearningPath lp : estudiante.getLearningPathsInscritos()) {
	                    System.out.println("Título: " + lp.getTitulo());
	                    System.out.println("Descripción: " + lp.getDescripcion());
	                    System.out.println("----------------------------");
	                }
	                break;

	            case 2:
	                // Iniciar actividad
	                System.out.print("Ingrese el título de la actividad que desea iniciar: ");
	                String tituloActividad = scanner.nextLine();
	                Actividad actividad = sistema.buscarActividadPorTitulo(tituloActividad);
	                if (actividad != null) {
	                    estudiante.iniciarActividad(actividad);
	                } else {
	                    System.out.println("Actividad no encontrada.");
	                }
	                break;

	            case 3:
	                // Calificar actividad
	                System.out.print("Ingrese el título de la actividad que desea calificar: ");
	                String tituloCalificar = scanner.nextLine();
	                Actividad actividadACalificar = sistema.buscarActividadPorTitulo(tituloCalificar);
	                if (actividadACalificar != null) {
	                    System.out.print("Ingrese la calificación (0-5): ");
	                    int calificacion = scanner.nextInt();
	                    scanner.nextLine(); // Consumir la línea
	                    estudiante.calificarActividad(actividadACalificar, calificacion);
	                } else {
	                    System.out.println("Actividad no encontrada.");
	                }
	                break;

	            case 4:
	                // Publicar reseña
	                System.out.print("Ingrese el título de la actividad para la reseña: ");
	                String tituloReseña = scanner.nextLine();
	                Actividad actividadAReseñar = sistema.buscarActividadPorTitulo(tituloReseña);
	                if (actividadAReseñar != null) {
	                    System.out.print("Escriba la reseña: ");
	                    String reseña = scanner.nextLine();
	                    estudiante.publicarReseña(reseña, actividadAReseñar);
	                } else {
	                    System.out.println("Actividad no encontrada.");
	                }
	                break;

	            case 5:
	                // Inscribirse en un Learning Path
	                System.out.print("Ingrese el título del Learning Path en el que desea inscribirse: ");
	                String tituloLearningPath = scanner.nextLine();
	                LearningPath learningPath = sistema.buscarLearningPathPorTitulo(tituloLearningPath);
	                if (learningPath != null) {
	                    estudiante.inscribirLearningPath(learningPath);
	                } else {
	                    System.out.println("Learning Path no encontrado.");
	                }
	                break;

	
	            case 6:
	                // Cerrar sesión
	                System.out.println("Cerrando sesión...");
	                return false; // Salir del menú

	            default:
	                System.out.println("Opción no válida. Intente de nuevo.");
	        }
	    }
	}
	public static boolean menuLearningPathsInscritos(Sistema sistema, Scanner scanner) throws SQLException {
	    ArrayList<LearningPath> LPsInscritos = sistema.getLPsInscritos(sistema.getSession().getLogin());

	    if (LPsInscritos.isEmpty()) {
	        System.out.println("No estás inscrito en ningún Learning Path.");
	        return false; // Volver al menú principal
	    }

	    for (int i = 0; i < LPsInscritos.size(); i++) {
	        System.out.println("[" + i + "] " + LPsInscritos.get(i).getTitulo());
	    }
	    System.out.println("[" + LPsInscritos.size() + "] Salir");
	    System.out.println("¿Qué learning path deseas consultar?: ");
	    int opcion = scanner.nextInt();
	    
	    while (opcion < 0 || opcion > LPsInscritos.size()) {
	        System.out.println("Por favor, digita una opción válida.");
	        opcion = scanner.nextInt();
	    }
	    
	    if (opcion == LPsInscritos.size()) {
	        return false; // Salir
	    } else {
	        boolean runLearningPath = true;
	        while (runLearningPath) {
		            runLearningPath = mostrarLearningPath(sistema, scanner, LPsInscritos, opcion);
		        }
		        return true; // Volver al menú
		    }
		}
	
		
		
		
		public static boolean mostrarLearningPath(Sistema sistema, Scanner scanner, ArrayList<LearningPath> LPsInscritos, int opcion) throws SQLException {
		    LearningPath LPEscogido = LPsInscritos.get(opcion);
		    System.out.println(LPEscogido.getTitulo());
		    System.out.println(LPEscogido.getDescripcion());
		    System.out.println("DIFICULTAD: " + LPEscogido.getDifficulty());
		    System.out.println("DURACION: " + String.valueOf(LPEscogido.getDuration()));
		    System.out.println("ACTIVIDADES:");
		    ArrayList<Actividad> actividades = LPEscogido.getActivities();
	
		    for (int i = 0; i < actividades.size(); i++) {
		        System.out.println("[" + String.valueOf(i) + "] " + actividades.get(i).getID());
		    }
		    System.out.println("[" + String.valueOf(actividades.size()) + "] Salir");
		    System.out.println("Opción: ");
		    int opcion2 = scanner.nextInt();
		    
		    if (opcion2 == actividades.size()) {
		        return false;
		    } else {
		        boolean runActividad = true;
		        while (runActividad) {
		            runActividad = mostrarActividad(sistema, scanner, actividades, opcion2);
		        }
		        return true;
		    }
		}
		
		
		
		
		public static void iniciarActividad(Sistema sistema, Scanner scanner) throws SQLException {
		    ArrayList<LearningPath> LPsInscritos = sistema.getLPsInscritos(sistema.getSession().getLogin());
	
		    if (LPsInscritos.isEmpty()) {
		        System.out.println("No tienes learning paths inscritos.");
		        return;
		    }
	
		    System.out.println("Selecciona el Learning Path en el que deseas iniciar una actividad:");
		    for (int i = 0; i < LPsInscritos.size(); i++) {
		        System.out.println("[" + i + "] " + LPsInscritos.get(i).getTitulo());
		    }
		    System.out.print("Elige una opción: ");
		    int opcionLP = scanner.nextInt();
	
		    while (opcionLP < 0 || opcionLP >= LPsInscritos.size()) {
		        System.out.println("Opción no válida. Por favor selecciona otra.");
		        opcionLP = scanner.nextInt();
		    }
	
		    LearningPath selectedLP = LPsInscritos.get(opcionLP);
		    ArrayList<Actividad> actividades = selectedLP.getActivities();
	
		    if (actividades.isEmpty()) {
		        System.out.println("No hay actividades disponibles en este Learning Path.");
		        return;
		    }
	
		    System.out.println("Actividades disponibles en " + selectedLP.getTitulo() + ":");
		    for (int i = 0; i < actividades.size(); i++) {
		        System.out.println("[" + i + "] " + actividades.get(i).getID());
		    }
		    System.out.print("Elige la actividad que deseas iniciar: ");
		    int opcionActividad = scanner.nextInt();
	
		    while (opcionActividad < 0 || opcionActividad >= actividades.size()) {
		        System.out.println("Opción no válida. Por favor selecciona otra.");
		        opcionActividad = scanner.nextInt();
		    }
	
		    Actividad actividadSeleccionada = actividades.get(opcionActividad);
		    
		} 
	
	
	
		
		public static boolean mostrarActividad(Sistema sistema, Scanner scanner, ArrayList<Actividad> actividades, int opcion) throws SQLException {
			Actividad actividadEscogida = actividades.get(opcion);
			System.out.println("Actividad : "+ String.valueOf(actividadEscogida.getID()));
			System.out.println(actividadEscogida.getDescripcion());
			System.out.println(actividadEscogida.getDifficulty());
			System.out.println(String.valueOf(actividadEscogida.getDuration()));
			System.out.println(actividadEscogida.getDateLimit());
			HashMap<String, String[]>states = actividadEscogida.getState();
			boolean yaAprobada = false;
			if (states.containsKey(sistema.getSession().getLogin())) {
				if (states.get(sistema.getSession().getLogin())[2].equals("false")) {
					System.out.println("[0] Iniciar actividad ");
				}else {
					yaAprobada = true;
				}
			}else {
				System.out.println("[0] Iniciar actividad ");
			}
			System.out.println("[1] salir");
			int opcion3 = scanner.nextInt();
			while (opcion3!=0 & opcion3!=1) {
				opcion3 = scanner.nextInt();
			}
			
			if (actividadEscogida.getClass().getSimpleName().equals("Quiz") & opcion3==0 & !yaAprobada) {
				
				HashMap<String, String[]> state = actividadEscogida.getState();
				if (!state.containsKey(sistema.getSession().getLogin())) {
					state.put(sistema.getSession().getLogin(), new String[3]);
					sistema.actualizarEstado(sistema.getSession(), actividadEscogida, LocalDate.now().toString() , "", false, false);
				}
				Quiz actividad = (Quiz) actividadEscogida;
				ArrayList<Pregunta> preguntas = actividad.getPreguntas();
				int respuestasBuenas = 0;
				for (int i =1 ; i <= preguntas.size(); i++) {
					System.out.println("Pregunta "+String.valueOf(i)+":");
					PreguntaOpcionMultiple pregunta= (PreguntaOpcionMultiple) preguntas.get(i-1);
					ArrayList<Opcion> opciones = pregunta.getOpciones();
					for (int j = 1; j<=opciones.size(); j++) {
						System.out.println("Opcion " + String.valueOf(j));
						Opcion opcioni = opciones.get(j-1);
						System.out.println(opcioni.getEnunciado());
					}
					System.out.println("Seleccione la opcion que considere correcta :");
					int respuestaUsuario = scanner.nextInt() -1;
					if (opciones.get(respuestaUsuario).getCorrect()) {
						respuestasBuenas+=1;
					}
					
				}
				if (respuestasBuenas >= actividad.getCalificacionMinima()) {
					System.out.println("Ha aprobado la actividad");
					sistema.actualizarEstado(sistema.getSession(), actividadEscogida,state.get(sistema.getSession().getLogin())[0],LocalDate.now().toString(), true, true );
					
				}
				return true;
			}if (actividadEscogida.getClass().getSimpleName().equals("Examen") & opcion3==0 & !yaAprobada) {
				HashMap<String, String[]> state = actividadEscogida.getState();
				if (!state.containsKey(sistema.getSession().getLogin())) {
					state.put(sistema.getSession().getLogin(), new String[3]);
					sistema.actualizarEstado(sistema.getSession(), actividadEscogida, LocalDate.now().toString() , "", false, false);
				}
				Examen actividad = (Examen) actividadEscogida;
				ArrayList<Pregunta> preguntas = actividad.getPreguntas();
			}
			else {
				return false;
			}
			
			
		} 
			
		public static boolean menuAplicacionProfesor(Sistema sistema, Scanner scanner) throws SQLException {
		    Profesor profesor = (Profesor) sistema.getSession();
	
		    while (true) {
		        System.out.println("\n--- Menú del Profesor ---");
		        System.out.println("[1] Crear Learning Path");
		        System.out.println("[2] Crear Actividad");
		        System.out.println("[3] Calificar Actividad");
		        System.out.println("[4] Calificar Examen");
		        System.out.println("[5] Publicar reseña");
		        System.out.println("[6] Ver Actividades Creadas");
		        System.out.println("[7] Ver Learning Paths Creados");
		        System.out.println("[8] Cerrar sesión");
		        System.out.print("¿Qué desea hacer? ");
	
		        int opcion = scanner.nextInt();
		        scanner.nextLine(); // Consumir la línea
	
		        switch (opcion) {
			        case 1:
		                // Crear Learning Path
		                System.out.print("Ingrese el título del Learning Path: ");
		                String tituloLP = scanner.nextLine();
		
		                System.out.print("Ingrese la descripción general: ");
		                String descripcionGeneral = scanner.nextLine();
		
		                System.out.print("Ingrese la dificultad (Basico, Intermedio, Avanzado): ");
		                String dificultad = scanner.nextLine();
		
		                System.out.print("Ingrese la duración en horas (Valores Enteros): ");
		                int duracion = scanner.nextInt();
		
		                System.out.print("Ingrese la calificación inicial de 0 a 5 (Valores Enteros): ");
		                int calificacion = scanner.nextInt();
		                scanner.nextLine(); // Consumir la línea
		
		                // Crear el Learning Path
		                String fechaCreacion = LearningPath.obtenerFechaActual(); // Método para obtener la fecha actual
		                LearningPath nuevoLP = new LearningPath(profesor.getLogin(), tituloLP, descripcionGeneral, dificultad, duracion, calificacion, fechaCreacion, fechaCreacion, sistema);
		                profesor.crearLearningPath(nuevoLP);
		                System.out.println("Learning Path creado con éxito.");
		                break;
		                
			        case 2:
			            // Crear Actividad
			            System.out.print("Ingrese el título de la Actividad: ");
			            String tituloActividad = scanner.nextLine();
	
			            System.out.print("Ingrese la descripción de la Actividad: ");
			            String descripcionActividad = scanner.nextLine();
	
			            System.out.print("Ingrese el objetivo de la Actividad: ");
			            String objetivoActividad = scanner.nextLine();
	
			            System.out.print("Ingrese la dificultad (Basico, Intermedio, Avanzado): ");
			            String nivelDificultad = scanner.nextLine();
	
			            System.out.print("Ingrese la duración en minutos (Valores Enteros): ");
			            int duracionActividad = scanner.nextInt();
			            scanner.nextLine(); // Consumir la línea
	
			            System.out.print("¿Es obligatoria? (true/false): ");
			            boolean obligatoria = scanner.nextBoolean();
			            scanner.nextLine(); // Consumir la línea
	
			            System.out.print("Ingrese la fecha límite (Formato: YYYY-MM-DD): ");
			            String fechaLimite = scanner.nextLine();
	
			            // Crea una nueva Actividad (puedes usar un constructor específico)
			            Actividad nuevaActividad = new Actividad(tituloActividad, descripcionActividad, objetivoActividad, nivelDificultad, duracionActividad, obligatoria, profesor.getLogin(), fechaLimite);
	
			            // Guarda la nueva actividad
			            profesor.crearActividad(nuevaActividad);
	
			            System.out.println("Actividad creada con éxito.");
			            break;
			            
			        case 3:
			            // Calificar Actividad
			            System.out.print("Ingrese el título de la Actividad que desea calificar: ");
			            String tituloActividadCalificar = scanner.nextLine();
			            
			            // Buscar la actividad por título
			            Actividad actividadACalificar = profesor.buscarActividadPorTitulo(tituloActividadCalificar);
			            if (actividadACalificar != null) {
			                System.out.print("Ingrese el login del estudiante: ");
			                String loginEstudiante = scanner.nextLine();
			                
			                Estudiante estudiante = sistema.buscarEstudiantePorLogin(loginEstudiante);
			                if (estudiante != null) {
			                    System.out.print("Ingrese la calificación (0 a 100): ");
			                    int calificacionActividad = scanner.nextInt();
			                    scanner.nextLine(); // Consumir la línea
			                    
			                    profesor.calificarActividad(actividadACalificar, estudiante, calificacionActividad);
			                    System.out.println("Actividad calificada con éxito.");
			                } else {
			                    System.out.println("Estudiante no encontrado.");
			                }
			            } else {
			                System.out.println("Actividad no encontrada.");
			            }
			            break;
			            
			        case 4:
			            // Calificar Examen
			            System.out.print("Ingrese el ID del examen que desea calificar: ");
			            int idExamen = scanner.nextInt();
			            scanner.nextLine(); // Consumir la línea
	
			            Examen examen = sistema.getExamenById(idExamen); // Obtener el examen por ID
			            if (examen == null) {
			                System.out.println("Examen no encontrado.");
			                break;
			            }
	
			            System.out.print("Ingrese el login del estudiante: ");
			            String loginEstudiante = scanner.nextLine(); // Cambiar a login en lugar de ID
	
			            Estudiante estudiante = sistema.buscarEstudiantePorLogin(loginEstudiante); // Usar el método para obtener el estudiante por login
			            if (estudiante == null) {
			                System.out.println("Estudiante no encontrado.");
			                break;
			            }
	
			            // Aquí puedes agregar la lógica para calificar el examen
			            System.out.print("Ingrese la calificación (0-5): ");
			            int calificacionInput = scanner.nextInt(); // Cambiar el nombre de la variable para evitar duplicación
			            scanner.nextLine(); // Consumir la línea
	
			            if (calificacionInput < 0 || calificacionInput > 5) {
			                System.out.println("Calificación inválida. Debe estar entre 0 y 5.");
			            } else {
			                // Supongamos que hay un método en la clase Examen para calificar
			                examen.setCalificacion(estudiante, calificacionInput);
			                System.out.println("Calificación registrada correctamente.");
			            }
			            break;
	
	
	
			        case 5:
			            // Publicar Reseña
			            System.out.print("Ingrese el título de la Actividad para la reseña: ");
			            String tituloActividadReseña = scanner.nextLine();
			            
			            Actividad actividadAReseñar = profesor.buscarActividadPorTitulo(tituloActividadReseña);
			            if (actividadAReseñar != null) {
			                System.out.print("Escriba la reseña para la actividad: ");
			                String reseña = scanner.nextLine();
			                
			                profesor.publicarReseña(actividadAReseñar, reseña);
			                System.out.println("Reseña publicada con éxito.");
			            } else {
			                System.out.println("Actividad no encontrada.");
			            }
			            break;
	
			            
			        case 6:
		                // Ver Actividades Creadas
		                System.out.println("--- Actividades Creadas ---");
		                for (Actividad actividad : profesor.getActividadesCreadas()) {
		                    System.out.println("Título: " + actividad.getNombre());
		                    System.out.println("Descripción: " + actividad.getDescripcion());
		                    System.out.println("Dificultad: " + actividad.getDifficulty());
		                    System.out.println("Duración: " + actividad.getDuration() + " minutos");
		                    System.out.println("Fecha Límite: " + actividad.getDateLimit());
		                    System.out.println("----------------------------");
		                }
		                break;
	
		            case 7:
		                // Ver Learning Paths Creados
		                System.out.println("--- Learning Paths Creados ---");
		                for (LearningPath lp : profesor.getLearningPathsCreados()) {
		                    System.out.println("Título: " + lp.getTitulo());
		                    System.out.println("Descripción: " + lp.getDescripcion());
		                    System.out.println("Dificultad: " + lp.getDifficulty());
		                    System.out.println("Duración: " + lp.getDuration() + " horas");
		                    System.out.println("Calificación: " + lp.getActivities());
		                    System.out.println("----------------------------");
		                }
		                break;
		                
		            case 8:
		                // Cerrar sesión
		                System.out.println("Cerrando sesión...");
		                return false; // Salir del menú	                
		                
			           
		            default:
		                System.out.println("Opción no válida. Intente de nuevo.");
		        }
		    }
		}
	}
	

