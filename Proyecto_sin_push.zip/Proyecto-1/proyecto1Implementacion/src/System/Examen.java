package System;

import java.util.ArrayList;
import java.util.HashMap;
import Usuarios.Estudiante;

public class Examen extends Actividad {
    ArrayList<Pregunta> preguntas;
    HashMap<Integer, HashMap<String, Object>> respuestas;

    // Constructor de Examen
    public Examen(String creator, int id, boolean mandatory, String descripcion, String difficulty, int duration, boolean started, String dateLimit, HashMap<String, String[]> states, ArrayList<Pregunta> preguntas, HashMap<Integer, HashMap<String, Object>> respuestas) {
        super(creator, id, mandatory, descripcion, difficulty, duration, started, dateLimit, states);
        this.preguntas = preguntas;
        this.respuestas = respuestas;
    }

    // Método para obtener las preguntas
    public ArrayList<Pregunta> getPreguntas() {
        return this.preguntas;
    }

    // Método para calificar el examen
    public void calificarExamen(Estudiante estudiante, int calificacion) {
        if (calificacion < 0 || calificacion > 5) {
            System.out.println("Error: La calificación debe estar entre 0 y 5.");
            return;
        }

        HashMap<String, Object> resultadoEstudiante = respuestas.get(estudiante.getID());
        if (resultadoEstudiante != null) {
            resultadoEstudiante.put("calificacion", calificacion);
        } else {
            HashMap<String, Object> nuevaCalificacion = new HashMap<>();
            nuevaCalificacion.put("calificacion", calificacion);
            respuestas.put(estudiante.getID(), nuevaCalificacion);
        }

        System.out.println("Calificación asignada correctamente.");
    }
    
    public void setCalificacion(Estudiante estudiante, int calificacion) {
        if (calificacion < 0 || calificacion > 5) {
            System.out.println("Error: La calificación debe estar entre 0 y 5.");
            return;
        }

        HashMap<String, Object> resultadoEstudiante = respuestas.get(estudiante.getID());
        if (resultadoEstudiante != null) {
            resultadoEstudiante.put("calificacion", calificacion);
        } else {
            HashMap<String, Object> nuevaCalificacion = new HashMap<>();
            nuevaCalificacion.put("calificacion", calificacion);
            respuestas.put(estudiante.getID(), nuevaCalificacion);
        }

        System.out.println("Calificación asignada correctamente.");
    }


    // Método para obtener la actividad
    public Actividad getActividad() {
        return this; // Retorna la instancia actual de Examen, que es una Actividad
    }
}

