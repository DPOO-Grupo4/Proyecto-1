package System;

import java.util.ArrayList;
import java.util.HashMap;

import Usuarios.Usuario;
import Usuarios.Estudiante;

public class Actividad {
    private String creator;
    private String nombre; // Título de la actividad
    public int id; // Identificador único de la actividad
    public boolean mandatory; // Indica si la actividad es obligatoria
    public String descripcion; // Descripción de la actividad
    public String difficulty; // Nivel de dificultad
    public int duration; // Duración estimada en minutos
    public boolean started; // Indica si la actividad ha sido iniciada
    public String dateLimit; // Fecha límite para completar la actividad
    private HashMap<String, String[]> state; // Estado de la actividad por estudiante
    private ArrayList<String> reseñas = new ArrayList<>(); // Reseñas sobre la actividad

    // Constructor de copia
    public Actividad(Actividad original) {
        this.nombre = original.nombre;
        this.creator = original.creator;
        this.id = original.id;
        this.mandatory = original.mandatory;
        this.descripcion = original.descripcion;
        this.difficulty = original.difficulty;
        this.duration = original.duration;
        this.started = original.started;
        this.dateLimit = original.dateLimit;
        this.state = new HashMap<>(original.state); // Copia profunda del estado
    }

    // Constructor principal
    public Actividad(String creator, int id, boolean mandatory, String descripcion, String difficulty, int duration, boolean started, String dateLimit, HashMap<String, String[]> states) {
        this.creator = creator;
        this.id = id;
        this.mandatory = mandatory;
        this.descripcion = descripcion;
        this.difficulty = difficulty;
        this.duration = duration;
        this.started = started;
        this.dateLimit = dateLimit;
        this.state = states;
    }

    // Constructor para crear una nueva actividad
    public Actividad(String tituloActividad, String descripcionActividad, String objetivoActividad,
                     String nivelDificultad, int duracionActividad, boolean obligatoria, String login, String fechaLimite) {
        this.nombre = tituloActividad; // Asignar el título
        this.descripcion = descripcionActividad; // Asignar la descripción
        this.difficulty = nivelDificultad; // Asignar el nivel de dificultad
        this.duration = duracionActividad; // Asignar la duración
        this.mandatory = obligatoria; // Asignar si es obligatoria
        this.creator = login; // Asignar el creador
        this.dateLimit = fechaLimite; // Asignar la fecha límite
        this.id = generarID(); // Generar un ID único
        this.started = false; // Inicializar como no iniciada
        this.state = new HashMap<>(); // Inicializar el estado
    }

    // Método para generar un ID único (puedes modificarlo según sea necesario)
    private int generarID() {
        // Lógica simple para generar un ID único
        return (int) (Math.random() * 10000); // ID aleatorio entre 0 y 9999
    }

    // Métodos getter
    public int getID() {
        return this.id;
    }

    public String getNombre() {
        return this.nombre; // Getter para el atributo nombre
    }

    public String getDescripcion() {
        return this.descripcion;
    }

    public String getDifficulty() {
        return this.difficulty;
    }

    public int getDuration() {
        return this.duration;
    }

    public String getDateLimit() {
        return this.dateLimit;
    }

    public HashMap<String, String[]> getState() {
        return this.state;
    }

    // Métodos setter
    public void setState(HashMap<String, String[]> state) {
        this.state = state;
    }

    // Método para agregar reseñas
    public void addReseña(String reseña) {
        reseñas.add(reseña);
    }

    // Método para editar la actividad
    public void editar(String nuevaDescripcion, String nuevaDificultad, int nuevaDuracion, String nuevaFechaLimite) {
        this.descripcion = nuevaDescripcion;
        this.difficulty = nuevaDificultad;
        this.duration = nuevaDuracion;
        this.dateLimit = nuevaFechaLimite;
    }

    // Método para cambiar el estado de la actividad
    public void cambiarEstado(Estudiante estudiante) {
        String idEstudiante = String.valueOf(estudiante.getID()); // Convertir el ID a String

        if (state.containsKey(idEstudiante)) {
            String[] estados = state.get(idEstudiante);
            estados[0] = "completado"; // Cambiar el estado a "completado"
        } else {
            String[] estados = {"completado"}; // Agregar nuevo estado si no existe
            state.put(idEstudiante, estados); // Convertimos el ID a String
        }
    }
    public void agregarReseña(String reseña) {
        if (reseña != null && !reseña.isEmpty()) {
            reseñas.add(reseña);
            System.out.println("Reseña agregada correctamente.");
        } else {
            System.out.println("La reseña no puede estar vacía.");
        }
    }

    // Método para calificar al estudiante
    public void calificarEstudiante(Estudiante estudiante, int calificacion) {
        String idEstudiante = String.valueOf(estudiante.getID()); // Convertir el ID a String

        if (state.containsKey(idEstudiante)) {
            String[] estados = state.get(idEstudiante);
            estados[1] = String.valueOf(calificacion); // Asignando la calificación
        } else {
            String[] estados = {"no iniciado", String.valueOf(calificacion)}; // Estado inicial y calificación
            state.put(idEstudiante, estados); // Convertimos el ID a String
        }
    }
}

